ei: 能源消费总量/GDP
FDI: 外资固定资产投资/GDP
IL:二产增加值占比
Lnpergdp:人均GDP 取对数
Ui：城镇人口比

数据来源：EPS  https://www-epsnet-com-cn-s.qh.yitlink.com:8444/index.html#/Index